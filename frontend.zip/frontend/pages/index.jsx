import Link from "next/link";
import { Component, Fragment } from "react";

class Home extends Component {
  render() {
    return (
      <div>
        Welcome to Luncher Box!
      </div>
    );
  }
}
export default Home;
